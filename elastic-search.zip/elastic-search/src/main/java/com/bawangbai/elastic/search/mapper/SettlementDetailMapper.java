package com.bawangbai.elastic.search.mapper;

import com.bawangbai.elastic.search.pojo.entity.SettlementDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.bawangbai.elastic.search.pojo.entity.SettlementDetail
 */
public interface SettlementDetailMapper extends BaseMapper<SettlementDetail> {

}