package com.example.shardsphere.jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShardsphereJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
