package com.example.shardsphere.jdbc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.shardsphere.jdbc.entity.User;

public interface UserService  extends IService<User> {
}
